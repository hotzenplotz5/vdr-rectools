# VDR-Rectools (V1.7.2)
Modulares Bash-Tool zur Verwaltung, Reparatur und zum Import von VDR-Aufnahmen.

## Features
* **Smart Import:** MKV/MP4 direkt als `.rec` verpacken inkl. sofortigem Plex-Symlink.
* **Auto-Subtitles:** Automatischer Download von deutschen SRT-Untertiteln bei Import (via Subliminal).
* **Reparatur:** Fehlerhafte Header/Timestamps korrigieren.
* **Smart Reporting:** Log-Inhalte werden intelligent per Mail versandt.
* **yaVDR Ansible Support:** Automatische Integration in das VDR OSD-Menü.

## Installation
Sichere Installation als Debian-Paket via `dpkg -i` oder über das offizielle APT-Repository.
